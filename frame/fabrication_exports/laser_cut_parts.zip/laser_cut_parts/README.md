## Notes on File Types

Most laser cutters will directly trace the lines and arcs present in a DXF file. For these laser cutters, use the **offset** files.

For the few laser cutters that perform *kerf compensation*, use the **original** files.

If you are unsure, using the **offset** files is probably your best bet.